var searchData=
[
  ['left_62',['left',['../class_bin_tree.html#a82108db4c1b08d1f111027788c196d4e',1,'BinTree']]],
  ['llegir_63',['llegir',['../class_cjt__missatges.html#a46d4d4f9a2fef92b2f8299b910405004',1,'Cjt_missatges::llegir()'],['../class_cjt__patrons.html#ac631f3d966d1bc6e80b1c2ad68ec1919',1,'Cjt_patrons::llegir()'],['../class_cjt__reixetes.html#a6abe4e1bda0d0c273301dd1349e47899',1,'Cjt_reixetes::llegir()'],['../class_patro.html#af535110182fc17af6eb4b7710b686142',1,'Patro::llegir()'],['../class_reixeta.html#aa08012fca755ed672e59277283e76344',1,'Reixeta::llegir()']]]
];
