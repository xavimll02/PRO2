var searchData=
[
  ['patro_69',['Patro',['../class_patro.html#a855fb6a1f19f9987695db51b059d7110',1,'Patro']]]
];
