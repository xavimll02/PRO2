var searchData=
[
  ['xifratge_20de_20missatges_3a_20reixetes_20i_20patrons_2e_33',['Xifratge de missatges: reixetes i patrons.',['../index.html',1,'']]]
];
