var searchData=
[
  ['patro_38',['Patro',['../class_patro.html',1,'']]]
];
