var searchData=
[
  ['nk_5fvalides_65',['nk_valides',['../class_reixeta.html#a9322151dcda428f88356fa284f59c4d1',1,'Reixeta']]],
  ['nou_5fmissatge_66',['nou_missatge',['../class_cjt__missatges.html#a0fd00caf68c05c8ccc045f2f71739c3b',1,'Cjt_missatges']]],
  ['nou_5fpatro_67',['nou_patro',['../class_cjt__patrons.html#a96ae76904a4c1357af908296a88a6d08',1,'Cjt_patrons']]],
  ['nova_5freixeta_68',['nova_reixeta',['../class_cjt__reixetes.html#ad23b7a7940426489b5480217375e24cf',1,'Cjt_reixetes']]]
];
