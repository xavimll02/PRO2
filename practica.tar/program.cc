/**
 * @mainpage Xifratge de missatges: reixetes i patrons.
 
Aquest programa modular ofereix un menú d'opcions per a gestionar el xifratge i el desxifratge de missatges. Les classes implicades són: 
<em>Reixeta</em>, <em>Patro</em>, <em>Cjt_missatges</em>, <em>Cjt_reixetes</em> i <em>Cjt_patrons</em>.
*/

/** @file program.cc
    @brief Programa principal pel projecte: <em>Xifratge de missatges</em>.
    
    Les dades llegides poden no ser correctes. Per això, hem aplicat el control d'errors adient per a
    cada operació introduïda.
*/

#include "Cjt_missatges.hh"
#include "Cjt_reixetes.hh"
#include "Cjt_patrons.hh"

int main() {
    
    Cjt_missatges missatges;
    missatges.llegir();
    
    Cjt_reixetes reixetes;
    reixetes.llegir();
    
    Cjt_patrons patrons;
    patrons.llegir();
    
    int idr; // Identificador reixeta
    int idp; // Identificador patro
    int mida_bloc; // Mida de bloc de missatge per a la seva codificacio per blocs amb un patro 
    string idm; // Identificador missatge
    string missatge;
    
    string comanda; // Operacio a realitzar
    cin >> comanda;
    
    while (comanda != "fin") {
        
        // "nuevo_mensaje" / "nm": afegeix un nou missatge al conjunt de missatges sempre
        // i quant no n'existeixi cap amb l'identificador introduit.
        if (comanda == "nuevo_mensaje" or comanda == "nm") { 
            
            cin >> idm;
            getline(cin, missatge);
            getline(cin, missatge);
            cout << '#' << comanda << ' ' << idm << endl;
            
            if (not missatges.existeix_missatge(idm)) missatges.nou_missatge(idm, missatge);
                
            else cout << "error: ya existe un mensaje con ese identificador" << endl;
        }
        
        // "nueva_rejilla" / "nr": afegeix una nova reixeta al conjunt de reixetes sempre i 
        // quant sigui valida.
        else if (comanda == "nueva_rejilla" or comanda == "nr") {
            
            Reixeta reixeta;
            reixeta.llegir();
            
            cout << '#' << comanda << endl;
            
            if (not reixeta.nk_valides()) cout << "error: dimensiones incorrectas de la rejilla" << endl;
            
            else if (not reixeta.buits_valids()) cout << "error: la rejilla con sus giros no cubre todas las posiciones N x N" << endl;
            
            else reixetes.nova_reixeta(reixeta);
        }
        
        // "nuevo_patron" / "np": afegeix un nou patro al conjunt de patrons.
        else if (comanda == "nuevo_patron" or comanda == "np") {
            
            Patro patro;
            patro.llegir();
            
            cout << '#' << comanda << endl;
            patrons.nou_patro(patro);
        }
        
        // "borra_mensaje" / "bm": esborra un missatge del conjunt de missatges sempre i
        // quant n'existeixi un amb l'identificador introduit.
        else if (comanda == "borra_mensaje" or comanda == "bm") {
            
            cin >> idm;
            cout << '#' << comanda << ' ' << idm << endl;
            
            if (not missatges.existeix_missatge(idm)) cout << "error: el mensaje no existe" << endl;
            
            else missatges.esborra_missatge(idm);
        }
        
        // "listar_mensajes" / "lm": llista el conjunt de missatges.
        else if (comanda == "listar_mensajes" or comanda == "lm") {
            
            cout << '#' << comanda << endl;
            missatges.escriure();
        }
        
        // "listar_rejillas" / "lr": llista el conjunt de reixetes.
        else if (comanda == "listar_rejillas" or comanda == "lr") {
            
            cout << '#' << comanda << endl;
            reixetes.escriure();
        }
        
        // "listar_patrones" / "lp": llista el conjunt de patrons.
        else if (comanda == "listar_patrones" or comanda == "lp") {
            
            cout << '#' << comanda << endl;
            patrons.escriure();
        }
        
        // "codificar_rejilla" / "cr": codifica un missatge amb una reixeta del conjunt de reixetes
        // sempre i quant existeixi una reixeta amb l'identificador introduit.
        else if (comanda == "codificar_rejilla" or comanda == "cr") {
            
            cin >> idr;
            getline(cin, missatge);
            getline(cin, missatge);
            cout << '#' << comanda << ' ' << idr << endl;
            
            if (not reixetes.existeix_reixeta(idr)) cout << "error: la rejilla no existe" << endl;
            
            else reixetes.codificar_missatge(idr, missatge);
        }
        
        // "codificar_guardado_rejilla" / "cgr": codifica un missatge del conjunt  de missatges amb
        // una reixeta del conjunt de reixetes sempre i quant existeixi un missatge i una reixeta
        // pels identificadors introduits.
        else if (comanda == "codificar_guardado_rejilla" or comanda == "cgr") {
            
            cin >> idm >> idr;
            cout << '#' << comanda << ' ' << idm << ' ' << idr << endl;
            
            if (not missatges.existeix_missatge(idm)) cout << "error: el mensaje no existe"  << endl;
            
            else if (not reixetes.existeix_reixeta(idr)) cout << "error: la rejilla no existe" << endl;
            
            else {
                    
                missatge = missatges.consultar_missatge(idm);
                reixetes.codificar_missatge(idr, missatge);
            }
        }
        
        // "decodificar_rejilla" / "dr": descodifica un missatge amb una reixeta del conjunt de reixetes
        // sempre i quant existeixi una reixeta amb l'identificador introduit i aquesta sigui compatible
        // per desencriptar.
        else if (comanda == "decodificar_rejilla" or comanda == "dr") {
            
            cin >> idr;
            getline(cin,missatge);
            getline(cin,missatge);
            cout << '#' << comanda << ' ' << idr << endl;
            
            if (not reixetes.existeix_reixeta(idr)) cout << "error: la rejilla no existe" << endl; 
            
            else if (not reixetes.compatible_per_desencriptar(idr, missatge)) cout << "error: la dimension del mensaje es inadecuada para la rejilla" << endl;
                
            else reixetes.descodificar_missatge(idr, missatge);
        }
        
        // "codificar_patron" / "cp": codifica un missatge per blocs amb un patro del conjunt de patrons
        // sempre i quant existeixi un patro amb l'identificador introduit.
        else if (comanda == "codificar_patron" or comanda == "cp") {
            
            cin >> idp >> mida_bloc;
            getline(cin, missatge);
            getline(cin, missatge);
            cout << '#' << comanda << ' ' << idp << ' ' << mida_bloc << endl;
            
            if (not patrons.existeix_patro(idp)) cout << "error: el patron no existe" << endl;
                
            else patrons.codificar_missatge(idp, missatge, mida_bloc);
        }
        
        // "codificar_guardado_patron" / "cgp": codifica un missatge del conjunt de missatges per blocs
        // amb un patro del conjunt de patrons sempre i quant existeixi un missatge i un patro pels 
        // identificadors introduits.
        else if (comanda == "codificar_guardado_patron" or comanda == "cgp") {
            
            cin >> idm >> idp >> mida_bloc;
            cout << '#' << comanda << ' ' << idm << ' ' << idp << ' ' << mida_bloc << endl;
            
            if (not missatges.existeix_missatge(idm)) cout << "error: el mensaje no existe" << endl; 
            
            else if (not patrons.existeix_patro(idp)) cout << "error: el patron no existe" << endl;
               
            else {
                    
                missatge = missatges.consultar_missatge(idm);
                patrons.codificar_missatge(idp, missatge, mida_bloc);
            }
        }
        
        // "decodificar_patron" / "dp": descodifica un missatge per blocs amb un patro del conjunt de
        // patrons sempre i quant existeixi un patro amb l'identificador introduit.
        else if (comanda == "decodificar_patron" or comanda == "dp") {
            
            cin >> idp >> mida_bloc;
            getline(cin, missatge);
            getline(cin, missatge);
            cout << '#' << comanda << ' ' << idp << ' ' << mida_bloc << endl;
            
            if (not patrons.existeix_patro(idp)) cout << "error: el patron no existe" << endl;
                
            else patrons.descodificar_missatge(idp, missatge, mida_bloc);
        }
    
        cin >> comanda;
    }
}
