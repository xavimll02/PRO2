/** @file Patro.cc
    @brief Codi de la classe Patro
*/

#include "Patro.hh"

Patro::Patro() {
}
   
void Patro::codifica(string& tros_missatge, const BinTree<int>& p, int i) const {
// Codifica tros_missatge segons el BinTree<int> pat del parametre implicit. Per aixo es tracta
// tros_missatge com si fos un arbre construit posant els seus caracters per nivells d'esquerra
// a dreta i se li suma a cada node imaginari l'int de pat que li correspon mitjançant una suma
// circular. Si pat no te node corresponent en una determinada posicio de tros_missatge, es
// comença a replicar de nou des de l'arrel. 2 * i + 1 correspon a la posicio del fill esquerre de
// tros_missatge[i] i 2 * i + 2 correspon a la del dret.
    
    tros_missatge[i] = 32 + (tros_missatge[i] + p.value() - 32) % 95;
    
    if (2 * i + 1 < tros_missatge.size()) {
        
        // HI1: tros_missatge[2 * i + 1] queda codificat amb p.left().value() si p.left() no es buit,
        // altrament tros_missatge[2 * i + 1] es codifica amb p.value()
        if (not p.left().empty()) codifica(tros_missatge, p.left(), 2 * i + 1);
        else codifica(tros_missatge, pat, 2 * i + 1);
    }
        
    if (2 * i + 2 < tros_missatge.size()) {
        
        // HI2: tros_missatge[2 * i + 2] queda codificat amb p.right().value() si p.right() no es buit,
        // altrament tros_missatge[2 * i + 2] es codifica amb p.value()
        if (not p.right().empty()) codifica(tros_missatge, p.right(), 2 * i + 2);
        else codifica(tros_missatge, pat, 2 * i + 2);
    }
}

void Patro::descodifica(string& tros_missatge, const BinTree<int>& p, int i) const {
// Descodifica tros_missatge segons el BinTree<int> pat del parametre implicit. Per aixo es tracta
// tros_missatge com si fos un arbre construit posant els seus caracters per nivells d'esquerra
// a dreta i se li resta a cada node imaginari l'int de pat que li correspon tambe de manera circular 
// per obtenir tros_missatge original. Si pat no te node corresponent en una determinada posicio 
// de tros_missatge, es comença a replicar de nou des de l'arrel.
    
    tros_missatge[i] = 32 + (((tros_missatge[i] - p.value() - 32) % 95) + 95) % 95; 
        
    if (2 * i + 1 < tros_missatge.size()) {
        
        // HI1: tros_missatge[2 * i + 1] queda descodificat amb p.left().value() si p.left() no es buit,
        // altrament tros_missatge[2 * i + 1] es descodifica amb p.value()
        if (not p.left().empty()) descodifica(tros_missatge, p.left(), 2 * i + 1);
        else descodifica(tros_missatge, pat, 2 * i + 1);
    }
        
    if (2 * i + 2 < tros_missatge.size()) {
        
        // HI2: tros_missatge[2 * i + 2] queda descodificat amb p.right().value() si p.right() no es buit,
        // altrament tros_missatge[2 * i + 2] es descodifica amb p.value()
        if (not p.right().empty()) descodifica(tros_missatge, p.right(), 2 * i + 2);
        else descodifica(tros_missatge, pat, 2 * i + 2);
    }
}
    
void Patro::codificar_missatge(const string& missatge, const int& mida_bloc) const {
// Codifica missatge per blocs de mida mida_bloc amb l'operacio privada codifica i finalment escriu
// la seva codificacio.
    
    double nBlocs = (double)missatge.size() / mida_bloc; // Nombre de blocs a codificar
    if ((int)nBlocs != nBlocs) nBlocs = (int)nBlocs + 1; // Si nBlocs no es un enter l'arrodonim a l'alça
    
    int bloc = 0, i = 0;
    string codificacio = "";
    
    // Inv: bloc es el nombre de blocs tractats, nBlocs es el nombre total de blocs, i es l'index inicial del bloc en 
    // que estem, codificacio es la codificacio dels blocs tractats, tros_missatge es el substring de missatge 
    // compres entre missatge[i] i missatge[i + mida_bloc - 1] i mida_bloc es la mida de bloc a codificar
    
    // Fita: nBlocs - bloc = 0
    while (bloc < nBlocs) {
        
        string tros_missatge = missatge.substr(i, mida_bloc);
        codifica(tros_missatge, pat, 0);
        codificacio += tros_missatge;
        ++bloc;
        i += mida_bloc;
    }
    cout << "\"" << codificacio << "\"" << endl;
}

void Patro::descodificar_missatge(const string& missatge, const int& mida_bloc) const {
// Descodifica missatge per blocs de mida mida_bloc amb l'operacio privada descodifica i finalment escriu
// la seva descodificacio.
    
    double nBlocs = (double)missatge.size() / mida_bloc; // Nombre de blocs a descodificar
    if ((int)nBlocs != nBlocs) nBlocs = (int)nBlocs + 1; // Si nBlocs no es un enter l'arrodonim a l'alça
    
    int bloc = 0, i = 0;
    string descodificacio = "";
    
    // Inv: bloc es el nombre de blocs tractats, nBlocs es el nombre total de blocs, i es l'index inicial del bloc en que 
    // estem, descodificacio es la descodificacio dels blocs tractats, tros_missatge es el substring de missatge compres 
    // entre missatge[i] i missatge[i + mida_bloc - 1] i mida_bloc es la mida de bloc a descodificar
    
    // Fita: nBlocs - bloc = 0
    while (bloc < nBlocs) {
        
        string tros_missatge = missatge.substr(i, mida_bloc);
        descodifica(tros_missatge, pat, 0);
        descodificacio += tros_missatge;
        i += mida_bloc;
        ++bloc;
    }
    cout << "\"" << descodificacio << "\"" << endl;
} 

void Patro::llegir_preordre(BinTree<int>& p) {
    
    int x; // Arrel
    cin >> x;
    
    if (x != -1){
        
        BinTree<int> esq;
        BinTree<int> dre;
        // HI1: llegir_preordre(esq) inicialitza el fill esquerre de p
        llegir_preordre(esq);
        // HI2: llegir_preordre(dre) inicialitza el fill dret de p
        llegir_preordre(dre);
        p = BinTree<int>(x, esq, dre); // p esta format per l'element x com a arrel i te com a fill esquerre BinTree<int> esq i com a dret BinTree<int> dre
    }
}

void Patro::escriure_preordre(const BinTree<int>& p) {
    
    if (p.empty()) cout << "()";
    
    else{
        
        cout <<  '(' << p.value();
        // HI1: escriure_preordre(p.left()) escriu el fill esquerre de p
        escriure_preordre(p.left());
        // HI2: escriure_preordre(p.right()) escriu el fill dret de p
        escriure_preordre(p.right());
        cout << ')';
    }
}

void Patro::llegir() {
// Inicialitza el parametre implicit llegint un BinTree d'enters mitjançant l'operacio privada llegir_preordre, amb marca -1
    
    llegir_preordre(pat);
}

void Patro::escriure() const {
// Escriu el contingut del parametre implicit cridant l'operacio privada escriure_preordre, amb el format ()
    
    escriure_preordre(pat);
    cout << endl;
}    

