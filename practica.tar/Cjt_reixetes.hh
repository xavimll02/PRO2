/** @file Cjt_reixetes.hh
    @brief Especificació de la classe Cjt_reixetes
*/

#ifndef _CJT_REIXETES_HH_
#define _CJT_REIXETES_HH_

#include "Reixeta.hh"
#ifndef NO_DIAGRAM
#include <vector>
#endif

/** @class Cjt_reixetes
    @brief Representa un conjunt de reixetes.

    És un conjunt que gestiona reixetes. Conte una operacio per inicialitzar el propi conjunt i emmagatzema reixetes i donat un identificador pot fer consultes sobre aquestes o manar encriptar o desencriptar un missatge. Tambe pot afegir-ne de noves i llistar-les.
*/

class Cjt_reixetes {
    
private:
    
    /** @brief vector de reixetes que conforma el conjunt de reixetes*/
    vector<Reixeta> r;
    
public:
    
    // Constructores
    
    /** @brief Constructora per defecte. 

      S'executa automàticament en declarar un conjunt de reixetes.
      \pre <em>cert</em>
      \post El resultat és un conjunt de reixetes no inicialitzat
  */  
    Cjt_reixetes();
    
    // Consultores
    
    /** @brief Consulta si existeix una reixeta. 
      \pre <em>cert</em>
      \post Retorna cert si existeix una reixeta amb identificador idr i fals altrament
  */  
    bool existeix_reixeta(const int& idr) const;
    
    /** @brief Consulta la compatibilitat d'un missatge amb la reixeta amb identificador idr per ser desencriptat.
      \pre <em>Existeix una reixeta al conjunt amb identificador idr</em>
      \post Retorna true si la mida de missatge es un múltiple de la n² de la reixeta idr i false altrament
  */ 
    bool compatible_per_desencriptar(const int& idr, const string& missatge) const;
    
    // Modificadores
    
    /** @brief Afegeix una nova reixeta al conjunt. 
      \pre <em>reixeta ha de ser vàlida</em>
      \post El paràmetre implícit conté una nova reixeta i s'ha escrit el nombre de reixetes actuals
  */  
    void nova_reixeta(const Reixeta& reixeta);
    
    // Lectura i Escriptura
    
        /** @brief Codifica un missatge mitjançant la reixeta idr.
      \pre <em>Existeix una reixeta al conjunt amb identificador idr</em>
      \post Es codifica missatge i s'escriu la codificacio pel canal estàndar de sortida
  */ 
    void codificar_missatge(const int& idr, const string& missatge) const;
    
    /** @brief Descodifica un missatge mitjançant la reixeta idr.
      \pre <em>Existeix una reixeta al conjunt amb identificador idr i aquesta és compatible amb missatge per descodificar-lo</em>
      \post Es descodifica missatge i s'escriu la descodificació pel canal estàndar de sortida
  */ 
    void descodificar_missatge(const int& idr, const string& missatge) const;
    
    /** @brief Operació de lectura.
      \pre <em>cert</em>
      \post S'ha inicialitzat el conjunt de reixetes
  */
    void llegir();
    
    /** @brief Operació d'escriptura.
      \pre <em>El paràmetre implícit està incialitzat</em>
      \post Escriu el contingut del paràmetre implícit pel canal estàndar de sortida
  */
    void escriure() const;
};

#endif
