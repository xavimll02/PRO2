/** @file Cjt_patrons.cc
    @brief Codi de la classe Cjt_patrons
*/

#include "Cjt_patrons.hh"

Cjt_patrons::Cjt_patrons() {
}

bool Cjt_patrons::existeix_patro(const int& idp) const {
// Indica si existeix un patro amb identificador idp (false si idp <=0 o idp > p.size(),
// true si 1 <= idp <= p.size() donat que en afegir-los se'ls assigna l'id segons el 
// tamany de p, vector del parametre implicit)
    
    if (idp <= 0 or idp > p.size()) return false;
    else return true;
}

void Cjt_patrons::nou_patro(const Patro& patro) {
// Afegeix un nou patro al conjunt de patrons (vector p del parametre implicit) i escriu
// el nombre de patrons de p
    
    p.push_back(patro);
    cout << p.size() << endl;
}

void Cjt_patrons::codificar_missatge(const int& idp, const string& missatge, const int& mida_bloc) const {
// Codifica un missatge per blocs de mida mida_bloc amb el patro amb identificador idp
// cridant codificar_missatge de la classe Patro
    
    p[idp - 1].codificar_missatge(missatge, mida_bloc);
}

void Cjt_patrons::descodificar_missatge(const int& idp, const string& missatge, const int& mida_bloc) const {
// Descodifica un missatge per blocs de mida mida_bloc amb el patro amb identificador idp
// cridant descodificar_missatge de la classe Patro
    
    p[idp - 1].descodificar_missatge(missatge, mida_bloc);
}

void Cjt_patrons::llegir() {
// Inicialitza el conjunt de patrons cridant la funció de llegir de la classe Patro
    
    int P; // Nombre de patrons a introduir
    cin >> P;
    p = vector<Patro>(P); // S'inicialitza el parametre implicit amb un vector de mida P
    
    for (int i = 0; i < P; ++i) p[i].llegir();
}

void Cjt_patrons::escriure() const {
// Llista els patrons de p cridant la funcio d'escriure de la classe Patro
    
    for (int i = 0; i < p.size(); ++i) {
        
        cout << "Patron " << i + 1 << ':' << endl;
        p[i].escriure();
    }
}
    
    
    
    
    
    
    
 
 
