/** @file Cjt_patrons.hh
    @brief  Especificació de la classe Cjt_patrons
*/

#ifndef _CJT_PATRONS_HH_
#define _CJT_PATRONS_HH_

#include "Patro.hh"
#ifndef NO_DIAGRAM
#include <vector>
#endif

/** @class Cjt_patrons
    @brief Representa un conjunt de patrons.

    És un conjunt que gestiona patrons. Conte una operacio per inicialitzar el propi conjunt i emmagatzema patrons i donat un identificador pot fer consultes sobre aquests o manar encriptar o desencriptar un missatge per blocs. Tambe pot afegir-ne de nous o llistar-los.
*/

class Cjt_patrons {
    
private:
    
    /** @brief vector de patrons que conforma el conjunt de patrons */
    vector<Patro> p;
    
public:
    
    // Constructores
    
    /** @brief Constructora per defecte. 

      S'executa automàticament en declarar un conjunt de patrons.
      \pre <em>cert</em>
      \post El resultat és un conjunt de patrons no inicialitzat
  */ 
    Cjt_patrons();
    
    // Consultores
    
    /** @brief Consulta si existeix un patró.
      \pre <em>cert</em>
      \post Retorna cert si existeix un patró amb identificador idp i fals altrament
  */  
    bool existeix_patro(const int& idp) const;
    
    // Modificadores
    
    /** @brief Afegeix un nou patró al conjunt. 
      \pre <em>cert</em>
      \post El paràmetre implícit conté un nou patró i s'ha escrit el nombre de patrons actuals
  */  
    void nou_patro(const Patro& patro);
    
    // Lectura i Escriptura
    
      /** @brief Codifica un missatge per blocs mitjançant el patró idp.
      \pre <em>Existeix un patró al conjunt amb identificador idp, mida_bloc > 0</em>
      \post  missatge es codifica per blocs de mida mida_bloc i s'escriu el resultat pel canal estàndar de sortida
  */ 
    void codificar_missatge(const int& idp, const string& missatge, const int& mida_bloc) const;
    
    /** @brief Descodifica un missatge per blocs mitjançant el patró idp.
      \pre <em>Existeix un patró al conjunt amb identificador idp, mida_bloc > 0</em>
      \post missatge es descodifica per blocs de mida mida_bloc i s'escriu el resultat pel canal estàndar de sortida
  */ 
    void descodificar_missatge(const int& idp, const string& missatge, const int& mida_bloc) const;
    
    /** @brief Operació de lectura.
      \pre <em>cert</em>
      \post S'ha inicialitzat el conjunt de patrons
  */
    void llegir();
    
    /** @brief Operació d'escriptura.
      \pre <em>El paràmetre implícit està incialitzat</em>
      \post Escriu el contingut del paràmetre implícit pel canal estàndar de sortida
  */
    void escriure() const;
    
};

#endif
