/** @file Reixeta.hh
    @brief Especificació de la classe Reixeta
*/

#ifndef _REIXETA_HH_
#define _REIXETA_HH_

#ifndef NO_DIAGRAM
#include <vector>
#include <algorithm>
#include <iostream>
#endif

using namespace std;

/** @class Reixeta
    @brief Representa una reixeta. 

    És una estructura continguda en una matriu de mida n i conté k buits. L'emprarem principalment per xifrar i desxifrar missatges amb el següent mètode: per xifrar es van posant k lletres dins els buits i un cop plens la reixeta es gira 90º, i així fins que la matriu on està continguda quedi plena. Si no cap tot el missatge en una sola matriu es repeteix el proces de nou per un altre bloc de caracters fins que tot el missatge esta xifrat, i si per al darrer bloc no hi ha prou lletres, s'omple amb espais. En canvi per desxifrar un missatge simplement es van escollint les posicions del missatge que indica el conjunt de buits de la reixeta, ja que es on han anat a parar els caracters ordenats quan s'ha xifrat el missatge.
*/

class Reixeta {
    
    // Descripcio: conte les caracteristiques d'una reixeta i les operacions necessaries per
    // gestionar el xifratge i desxifratge de missatges. Una reixeta pot no ser valida si no
    // compleix 4k = n² o que en el seu conjunt de buits no hi ha cap posicio repetida, el
    // que priva de poder codificar i descodificar
    
private:
    
    /** @brief Dimensió de la matriu on està continguda la reixeta */
    int n;  
    /** @brief Nombre de buits de la reixeta */
    int k; 
    /** @brief Validesa del conjunt de buits de la reixeta*/
    bool buits_correctes;
    /** @brief Validesa de la n i la k de la reixeta*/
    bool nk_correctes;
    /** @brief Conjunt de buits de la reixeta */
    vector<vector<pair<int,int>>> buits;
    
public:
    
    // Constructores
    
    /** @brief Constructora per defecte. 

      S'executa automàticament en declarar una reixeta.
      \pre <em>cert</em>
      \post El resultat és una reixeta amb els atributs buits_correctes i nk_correctes inicialitzats.
  */  
    Reixeta();
    
    // Consultores
    
    /** @brief Consulta la validesa de la condició 4k = n². 
      \pre <em>El paràmetre implícit està inicialitzat</em>
      \post Retorna true si la reixeta compleix 4k = n² i fals altrament
  */  
    bool nk_valides() const;
    
    /** @brief Consulta la validesa de la condició no es pot repetir cap buit. 
      \pre <em>El paràmetre implícit està inicialitzat</em>
      \post Retorna true si en el conjunt de buits de la reixeta no es repeteix cap posicio, i fals altrament
  */  
    bool buits_valids() const;
    
    /** @brief Consulta la compatibilitat d'un missatge amb una reixeta per ser desencriptat.
      \pre <em>El paràmetre implícit està inicialitzat</em>
      \post Retorna true si la mida de missatge es un múltiple de n * n i false altrament
  */ 
    bool compatible_per_desencriptar(const string& missatge) const;
    
    // Lectura i escriptura
    
       /** @brief Xifra un missatge.
      \pre <em>El paràmetre implícit està inicialitzat i és consistent (reixeta vàlida)</em>
      \post S'escriu pel canal estàndar de sortida missatge codificat
  */  
    void codificar_missatge(const string& missatge) const;
    
    /** @brief Desxifra un missatge.
      \pre <em>El paràmetre implícit constitueix una reixeta consistent (vàlida) i compatible per desencriptar amb missatge</em>
      \post S'escriu pel canal estàndar de sortida missatge descodificat
  */  
    void descodificar_missatge(const string& missatge) const;
    
    /** @brief Operació de lectura.
      \pre <em>cert</em>
      \post El paràmetre implícit conté la mida n, el nombre de buits k, el conjunt de buits mentre han estat valids i la validesa d'aquests i de nk
  */
    void llegir();
    
    /** @brief Operació d'escriptura.
      \pre <em>El paràmetre implícit està incialitzat</em>
      \post Escriu el contingut del paràmetre implícit pel canal estàndar de sortida
  */
    void escriure() const;
    
};

#endif
