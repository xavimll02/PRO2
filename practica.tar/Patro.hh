/** @file Patro.hh
    @brief  Especificació de la classe Patro
*/

#ifndef _PATRO_HH_
#define _PATRO_HH_

#ifndef NO_DIAGRAM
#include "BinTree.hh"
#include <iostream>
#endif

using namespace std;

/** @class Patro
    @brief Representa un patró. 

    És un arbre d'enters entre 0 i 94 que té qualsevol forma. L'emprarem principalment per xifrar i desxifrar missatges amb el següent mètode: per xifrar s'ha de tractar cada missatge com un arbre imaginari que recorregut per nivells d'esquerra a dreta forma el missatge, i replicar el patró respectant la forma d'aquest arbre fins a cubrir-lo tot, formant un mosaic amb la finalitat d'aplicar una suma circular a cada caràcter perquè el missatge quedi codificat. Per desxifrar un missatge el procés és exactament el mateix però per comptes d'una suma es fa una resta.
*/

class Patro {
    
    // Descripcio: conte l'arbre d'enters que codifica pero a mes a mes, operacions
    // publiques i privades auxiliars per gestionar el xifratge i el desxifratge de missatges
    
private:

    /** @brief BinTree d'enters que conforma un patró */
    BinTree<int> pat;
    
    /** @brief Codifica un bloc d'un missatge amb un patró donat.
      \pre <em>tros_missatge = T, p = pat, i = 0</em>
      \post tros_missatge conté T codificat mitjançant p
  */ 
    void codifica(string& tros_missatge, const BinTree<int>& p, int i) const;
    
    /** @brief Descodifica un bloc d'un missatge amb un patró donat.
      \pre <em>tros_missatge = T, p = pat, i = 0</em>
      \post tros_missatge conté T descodificat mitjançant p
  */ 
    void descodifica(string& tros_missatge, const BinTree<int>& p, int i) const;
    
    /** @brief Lectura d'un arbre.
      \pre <em>cert</em>
      \post S'ha llegit un patró arborescent en preordre i marca -1
  */ 
    static void llegir_preordre(BinTree<int> &p);
    
    /** @brief Escriptura d'un arbre.
      \pre <em>El paràmetre implícit està inicialitzat</em>
      \post Escriu el contingut d'un patró pel canal estàndar de sortida
  */
    static void escriure_preordre(const BinTree<int>& p);
    
public:
    
    // Constructores
    
    /** @brief Constructora per defecte. 
     
      S'executa automàticament en declarar un patró.
      \pre <em>cert</em>
      \post El resultat es un patró buit
  */  
    Patro();
    
    // Lectura i Escriptura
    
    /** @brief Xifra un missatge.
      \pre <em>El paràmetre implícit està inicialitzat, mida_bloc > 0</em>
      \post Es codifica missatge i la codificació s'escriu pel canal estàndar de sortida
  */  
    void codificar_missatge(const string& missatge, const int& mida_bloc) const;
    
    /** @brief Desxifra un missatge.
      \pre <em>El paràmetre implícit està iniciaitzat, mida_bloc > 0</em>
      \post Es descodifica missatge i la descodificació s'escriu pel canal estàndar de sortida
  */  
    void descodificar_missatge(const string& missatge, const int& mida_bloc) const;
    
    /** @brief Operació de lectura.
      \pre <em>cert</em>
      \post S'ha inicialitzat el patró
  */
    void llegir();
    
    /** @brief Operació d'escriptura.
      \pre <em>El paràmetre implícit està inicialitzat</em>
      \post Escriu el contingut del paràmetre implícit pel canal estàndar de sortida
  */
    void escriure() const;
};

#endif
