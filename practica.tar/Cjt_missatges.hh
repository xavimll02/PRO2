/** @file Cjt_missatges.hh
    @brief  Especificació de la classe Cjt_missatges
*/

#ifndef _CJT_MISSATGES_HH_
#define _CJT_MISSATGES_HH_

#ifndef NO_DIAGRAM
#include <iostream>
#include <map>
#endif

using namespace std;

/** @class Cjt_missatges
    @brief Representa un conjunt de missatges. 

    És un conjunt que gestiona missatges. Conte una operacio per inicialitzar el propi conjunt i emmagatzema missatges i donat un identificador pot fer consultes sobre aquests o esborrar-ne o afegir-ne de nous. Tambe pot llistar-los juntament amb el seu identificador. 
*/
class Cjt_missatges {
    
private:
    
    /** @brief map de parells de strings ("identificador-missatge") que conforma el conjunt de missatges*/
    map<string, string> m;
    
public:
    
    // Constructores
    
    /** @brief Constructora per defecte. 

      S'executa automàticament en declarar un conjunt de missatges.
      \pre <em>cert</em>
      \post El resultat és un conjunt de missatges no inicialitzat.
  */ 
    Cjt_missatges();
    
    // Consultores
    
    /** @brief Consulta si existeix un missatge.
      \pre <em>cert</em>
      \post Retorna cert si existeix un missatge amb identificador idm i fals altrament
  */  
    bool existeix_missatge(const string& idm) const;
    
    /** @brief Consulta un missatge del conjunt. 
      \pre <em>Existeix un missatge al conjunt amb identificador idm</em>
      \post Retorna el missatge amb identificador idm
  */  
    string consultar_missatge(const string& idm) const;
    
    // Modificadores
    
    /** @brief Afegeix un nou missatge al conjunt. 
      \pre <em>No existeix cap missatge amb identificador idm</em>
      \post El paràmetre implícit conté un nou missatge i s'escriu el nombre de missatges del moment
  */  
    void nou_missatge(const string& idm, const string& missatge);
    
    /** @brief Elimina un missatge del conjunt. 
      \pre <em>Existeix un missatge al conjunt amb identificador idm</em>
      \post El paràmetre implícit s'ha modificat llevant el missatge amb identificador idm i s'escriu el nombre de missatges del moment
  */  
    void esborra_missatge(const string& idm);
    
    // Lectura i Escriptura
    
    /** @brief Operació de lectura.
      \pre <em>cert</em>
      \post S'ha inicialitzat el conjunt de missatges
  */
    void llegir();
    
    /** @brief Operació d'escriptura.
      \pre <em>El paràmetre implícit està incialitzat</em>
      \post Escriu el contingut del paràmetre implícit pel canal estàndar de sortida
  */
    void escriure() const;
    
};

#endif
