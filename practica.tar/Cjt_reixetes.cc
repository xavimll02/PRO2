/** @file Cjt_reixetes.cc
    @brief Codi de la classe Cjt_reixetes
*/

#include "Cjt_reixetes.hh"

Cjt_reixetes::Cjt_reixetes() {
}

bool Cjt_reixetes::existeix_reixeta(const int& idr) const {
// Indica si existeix una reixeta amb identificador idr (false si idr <=0 o
// idr > r.size(), true si 1 <= idr <= r.size() donat que en afegir-los se'ls 
// assigna l'id segons el tamany de r, vector del parametre implicit)
    
    if (idr <= 0 or idr > r.size()) return false;
    else return true;
}

bool Cjt_reixetes::compatible_per_desencriptar(const int& idr, const string& missatge) const {
// Indica si un missatge es compatible per desencriptar amb una reixeta
// amb identificador idr amb la crida compatible_per_desencriptar de
// la classe Reixeta
    
    return r[idr - 1].compatible_per_desencriptar(missatge);
}

void Cjt_reixetes::nova_reixeta(const Reixeta& reixeta) {
// Afegeix una nova reixeta al conjunt de reixetes (vector r del parametre implicit) i escriu
// el nombre de reixetes de r
    
    r.push_back(reixeta);
    cout << r.size() << endl;
}

void Cjt_reixetes::codificar_missatge(const int& idr, const string& missatge) const {
// Codifica un missatge amb la reixeta amb identificador idr amb la crida
// a codificar_missatge de la classe Reixeta
    
    r[idr - 1].codificar_missatge(missatge);
}
    
void Cjt_reixetes::descodificar_missatge(const int& idr, const string& missatge) const {
// Descodifica un missatge amb la reixeta amb identificador idr amb la crida
// a descodificar_missatge de la classe Reixeta
    
    r[idr - 1].descodificar_missatge(missatge);
}

void Cjt_reixetes::llegir() {
// Inicialitza el conjunt de reixetes cridant la funció de llegir de la classe Reixeta
    
    int R; // Nombre de reixetes a introduir
    cin >> R;
    r = vector<Reixeta>(R); // S'inicialitza el parametre implicit amb un vector de mida R
    
    for (int i = 0; i < R; ++i) r[i].llegir();        
}

void Cjt_reixetes::escriure() const {
// Llista les reixetes de r cridant la funcio d'escriure de la classe Reixeta
    
    for (int i = 0; i < r.size(); ++i) {
        
        cout << "Rejilla " << i + 1 << ':' << endl;
        r[i].escriure();
    }
}
        
             
