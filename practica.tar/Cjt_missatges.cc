/** @file Cjt_missatges.cc
    @brief Codi de la classe Cjt_missatges
*/

#include "Cjt_missatges.hh"

Cjt_missatges::Cjt_missatges() {
}

bool Cjt_missatges::existeix_missatge(const string& idm) const {
// Indica si existeix un missatge amb identificador idm (false si it apunta a m.end(),
// el que vol dir que no l'ha trobat i true altrament). m es un map<string, string>
// que ens ordena els missatges per identificador en ordre alfabetic
    
    map<string, string>:: const_iterator it = m.find(idm);
    if (it != m.end()) return true;
    else return false;
}

string Cjt_missatges::consultar_missatge(const string& idm) const {
// Consulta un missatge amb identificador idm
    
    map<string, string>:: const_iterator it = m.find(idm);
    return (*it).second;
}

void Cjt_missatges::nou_missatge(const string& idm, const string& missatge) {
// Afegeix un nou missatge amb identificador idm al conjunt de missatges
// m del parametre implicit i escriu el seu nombre de missatges
    
    pair<string, string> nouMissatge(idm, missatge);
    m.insert(nouMissatge);
    cout << m.size() << endl;
}

void Cjt_missatges::esborra_missatge(const string& idm) {
// Esborra el missatge amb identificador idm i escriu el nombre de missatges
// que hi queden
    
    map<string, string>:: iterator it = m.find(idm);
    m.erase(it);
    cout << m.size() << endl;
}

void Cjt_missatges::llegir() {
// Inicialitza el conjunt de missatges
    
    int M; // Nombre de missatges a introduir
    cin >> M;
    
    for (int i = 0; i < M; ++i) {
        
        string id; // Identificador de missatge
        cin >> id;
        string missatge;
        getline(cin, missatge);
        getline(cin, missatge);
        pair<string, string> nouMissatge(id, missatge);
        m.insert(nouMissatge);
    }
}

void Cjt_missatges::escriure() const {
// Llista els identificadors dels missatges juntament amb el seu missatge
    
    for (map<string, string>:: const_iterator it = m.begin(); it != m.end(); ++it) {
        
        cout << (*it).first  << endl;
        cout << "\"" << (*it).second << "\"" << endl;
    }
}
        
        
        
    
