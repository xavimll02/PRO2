/** @file Reixeta.cc
    @brief Codi de la classe Reixeta
*/

#include "Reixeta.hh"

Reixeta::Reixeta() {
    
    // Inicialitza una reixeta amb buits valids i nk valides a true
    buits_correctes = true;
    nk_correctes = true;
}

bool Reixeta::nk_valides() const {
// Indica si el nombre de buits k d'una reixeta es compatible amb la dimensio n 
// de la matriu on esta continguda (true: si, false: no)
    
    return nk_correctes;
}

bool Reixeta::buits_valids() const {
// Indica si en el conjunt de buits d'una reixeta es repeteix alguna posicio (true: son valids,
// false: no son valids)
    
    return buits_correctes;
}
    
bool Reixeta::compatible_per_desencriptar(const string& missatge) const {
// Indica si un missatge es compatible per desencriptar amb una reixeta. Per això 
// s'ha de donar que la mida del missatge sigui un multiple de n * n.
    
    if (missatge.size() % (n * n) == 0) return true;
    else return false;
}

void Reixeta::codificar_missatge(const string& missatge) const {
// Codifica un missatge segons una reixeta a base de col·locar barrejats cada un dels seus 
// caracters en un vector codificacio que treballa de conjunt de matrius desplegades, 
// concretament en la posicio indicada pels buits de la reixeta que, dins cada gir, estan en 
// ordre ascendent (necessari per posar les lletres en ordre). Un bloc s'interpreta com una 
// matriu n * n i se n'han de tractar tants com siguin necessaris per tenir tot el missatge
// codificat repetint el proces esmentat. Finalment s'escriu la codificacio.
    
    double nBlocs = (double)missatge.size() / (n * n); // Nombre de blocs a codificar
    if ((int)nBlocs != nBlocs) nBlocs = (int)nBlocs + 1; // Si nBlocs no es un enter l'arrodonim a l'alça
    vector<char> codificacio(n * n * nBlocs, ' '); // codificacio es un vector de chars amb nBlocs matrius n * n inicialitzades
                                                                          // amb ' ' perquè, davant la possibilitat que l'ultim bloc no s'ompli, ja hi hagi
                                                                          // els espais posats per deixar-lo ple i poguem aturar
    int bloc = 0, index_missatge = 0;  
    
    // Inv: bloc es el nombre de blocs tractats, nBlocs es el nombre total de blocs, i es la fila 
    // que estem tractant del conjunt de buits, aturam es un bool que indica si ja hem tractat 
    // tots els carracters de missatge, j es la columna que estem tractant del conjunt de buits, 
    // index_missatge indica l'index a accedir de missatge i codificacio es la codificacio dels 
    // caracters de missatge tractats fins el moment.
    
    // Fita: nBlocs - bloc = 0
    while (bloc < nBlocs) {
    
        int i = 0; 
        bool aturam = false;
        while(not aturam and i < 4) {
            
            int j = 0;
            while (not aturam and j < k) {
                
                if (index_missatge < missatge.size()) codificacio[(buits[i][j].first - 1) * n + buits[i][j].second - 1 + bloc * n * n] = missatge[index_missatge];
                else aturam = true;    
                ++index_missatge;
                ++j;
            }
            
            ++i;
        }
        
        ++bloc;
    }
    
    cout << "\"";
    for (int l = 0; l < codificacio.size(); ++l) cout << codificacio[l];
    cout << "\"" << endl;
}

void Reixeta::descodificar_missatge(const string& missatge) const {
// Descodifica un missatge segons una reixeta a base d'escriure directament les posicions
// de missatge que ens indica la matriu de buits a mesura que la recorrem. Quant s'ha
// tractat un bloc que son 4k caracters, hem de repetir el proces per als 4k seguents
// i aixi fins haver-los tractats tots
    
    int bloc = 0, car_tractats = 0;
    
    cout << "\"";
    
    // Inv: car_tractats es el nombre de caracters tractats, bloc es el bloc actual.
    
    // Fita: missatge.size() - car_tractats = 0
    while (car_tractats < missatge.size()) {
        
        for (int i = 0;  i < 4; ++i) {
            for (int j = 0; j < k; ++j) cout << missatge[(buits[i][j].first - 1) * n + buits[i][j].second - 1 + bloc * n * n];
        }
    
        ++bloc;
        car_tractats += 4 * k;
    }
    
    cout << "\"" << endl;
}

void Reixeta::llegir() {
// Inicialitza el parametre implicit llegint la dimensio n, el nombre de posicions k i els k
// buits inicials, i a aquests darrers els deixa ordenats. A mes si n i k eren valides, completa 
// el conjunt de buits de la reixeta resultants de girarla 90º, 180º i 270º mentre no se'n 
// repeteixi cap, i els ordena ascendentment tambe per girs.
    
    cin >> n >> k;
    if (4 * k != n * n) nk_correctes = false;
    
    pair<int, int> buit;
    buits = vector<vector<pair<int,int>>>(4, vector<pair<int, int>>(k)); // Assignem a buits una matriu 4k de parells d'enters que
                                                                                                                    // seran posicions de la matriu n * n
    vector<vector<bool>> pos_visitades(n, vector<bool>(n, false)); // Matriu de bools que indiquen amb false si no s'ha visitat
                                                                                                            // i amb true si ja ha estat visitat 
    for (int i = 0; i < k; ++i) {
        
        cin >> buit.first >> buit.second; 
        buits[0][i] = buit;
        pos_visitades[buits[0][i].first - 1][buits[0][i].second - 1] = true; // Es marquen ja com a visitats els buits inicials
    }
    
    sort(buits[0].begin(), buits[0].end());
    
    if (nk_correctes) { // Si la n i la k no eren valides ja podem parar, altrament calculam el conjunt de buits
                                  // i si apareix la mateixa posicio mes d'un cop la reixeta tampoc sera valida i pararem
        int j = 1;
        while (buits_correctes and j < 4) {
            
            int l = 0; 
            while (buits_correctes and l < k) {
                
                buits[j][l].first = n - buits[j - 1][l].second + 1; // "fila_nova = n - columna_anterior + 1"
                buits[j][l].second = buits[j - 1][l].first; // "columna_nova = fila_anterior"
                    
                if (not pos_visitades[buits[j][l].first - 1][buits[j][l].second - 1]) pos_visitades[buits[j][l].first - 1][buits[j][l].second - 1] = true;
                else buits_correctes = false;
                l++;
            }
            sort(buits[j].begin(), buits[j].end());
            j++;
        }
    }
}

void Reixeta::escriure() const {
// Escriu el contingut del parametre implicit: n, k i a partir de la seguent linia el conjunt
// de buits
    
    cout << n << ' ' << k << endl;
    
    for (int i = 0; i < 4; ++i) {
        for (int j = 0; j < k; ++j) {
           
            if (j > 0) cout << " ";
            cout << '(' << buits[i][j].first << ',' << buits[i][j].second << ')';
        }
        cout << endl;
    }
}
        
        
        
